#ifndef EXTRACTION_NODE_HPP
#define EXTRACTION_NODE_HPP

namespace osrm
{
namespace extractor
{

struct ExtractionNode
{
    ExtractionNode() : traffic_lights(false), barrier(false), railway(false) {}
    void clear() { traffic_lights = barrier = railway = false; }
    bool traffic_lights;
    bool barrier;
    bool railway;
};
} // namespace extractor
} // namespace osrm

#endif // EXTRACTION_NODE_HPP
