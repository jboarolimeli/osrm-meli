#!/bin/bash

cat <<EOF
  **********************************************************************************

  Hello world!!!!!!!

  It's a very simple command running from fury. You can use it 
  as start point to create new and fantastic apps, howerver, if you will work
  with grails or another common language we encourage you to use common images like
  *mlarq/grails* for test and *mlarq/tomcat-runtime* for the Docker.runtime file 
  
  **********************************************************************************
EOF
