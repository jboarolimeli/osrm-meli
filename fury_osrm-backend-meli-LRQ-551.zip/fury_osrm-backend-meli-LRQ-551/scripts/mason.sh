#!/usr/bin/env bash

cmake -P cmake/mason.cmake "$@"
