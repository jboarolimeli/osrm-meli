#ifndef EXTRACTION_NODE_HPP
#define EXTRACTION_NODE_HPP

namespace osrm
{
namespace extractor
{

struct ExtractionNode
{
    ExtractionNode()
        : traffic_lights(false), barrier(false), railway(false), car_charge(0),
          motorcycle_charge(0), axle_charge(0)
    {
    }
    void clear()
    {
        traffic_lights = barrier = railway = false;
        car_charge = motorcycle_charge = axle_charge = 0;
    }
    bool traffic_lights;
    bool barrier;
    bool railway;
    float car_charge;
    float motorcycle_charge;
    float axle_charge;
};
} // namespace extractor
} // namespace osrm

#endif // EXTRACTION_NODE_HPP
