#!/bin/bash

cat <<EOF

  **********************************************************************************
  
  In this script our fantastic app will be builded to be put in production

  **********************************************************************************
EOF
